import PostForm from "../ui/PostForm";

export default function NewPostPage() {
  return (
    <main className="flex justify-center my-4">
      <PostForm />
    </main>
  );
}
