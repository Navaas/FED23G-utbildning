## Frontend Ramverk

Datum: 2024-02-16

Uppgiften är att välja valfritt ramverk och efterlikna en lista med olika ramverk. Jag har valt Vue tillsammans med Typescript.
![Example](https://user-images.githubusercontent.com/17639389/210244688-34d58e7d-1c6c-4c43-a3ec-e01f89dd7abd.jpg)

### Detta finns i projektet

- `npm install vite@latest` eller `npm create vite@latest`
- Typescript, Vue och Tailwind.
- `nmp install`, `npm run dev`

- Tailwind CSS - [Tailwinds hemsida](https://tailwindcss.com/)

### För att starta

- `npm install`
- `npm run dev`

### Tester

För att kolla mina tester har jag använt Cypress. Se listan nedan.
Kör testerna med : `npx plugga test`

- `data-cy="chart"` diagrammet över ramverken och dess data.
- `data-cy="chart-header-cell"` varje cell i övre delen av diagrammet som visar åren (2016-2022).
- `data-cy="chart-data-cell"` varje cell i nedre delen av diagrammet som visar ramverken (även tomma).
- `data-cy="chart-circle"` värdet som visas i en cell - en färgad cirkel med en procentsats.

### Krav för Godkänt

- [x] Uppgiften har lämnats in i tid (Kod & Presentation).
- [x] Readmefilen har uppdaterats enligt beskrivning ovan.
- [x] Git och GitHub har använts.
- [x] Sidan innehåller en header, footer och main.
- [x] Sidan är responsiv.
- [x] Sidan visar "retention" informationen som finns i [data filen](./data/index.js) i enlighet med bilden ovan.

## Resultat

### Desktop view

![Ramverk desktop](/src/assets/Ramverk-1.png "Desktop")

### Mobile view

![Ramverk mobile](/src/assets/Ramverk-2.png "Mobile")

### Tester

![Ramverk tester](/src/assets/Ramverk-tester.png "Tester")
