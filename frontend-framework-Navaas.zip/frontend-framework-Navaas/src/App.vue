<script setup lang="ts">
import Footer from "./components/Footer.vue";
import Header from "./components/Header.vue";
import Main from "./components/Main.vue";
</script>

<template>
  <Header></Header>
  <Main></Main>
  <Footer></Footer>
</template>
