<script setup lang="ts">
import { frameworks } from "../../data/index.ts";

/**
 * Ths code uses the array method flatMap() together with Set to create unique list of year from an array of frameworkds and theirs surveys.
 */
const years = Array.from(
  new Set(
    frameworks.flatMap((framework) =>
      framework.surveys.map((survey) => survey.year)
    )
  )
);
</script>

<template>
  <main className="bg-zinc-800">
    <section
      data-cy="chart"
      className="grid grid-cols overflow-x-auto max-w-[1000px] mx-auto"
    >
      <section className="grid grid-cols-9 py-8">
        <article data-cy="chart-header-cell"></article>
        <!-- V-FOR FOR YEAR. This loop loops the year in array and render this in a h2. -->
        <article
          v-for="year in years"
          :key="year"
          className="text-white text-center self-end"
          data-cy="chart-header-cell"
        >
          <!-- Render te year -->
          <h2 className="text-xs md:text-lg">{{ year }}</h2>
        </article>
        <article data-cy="chart-header-cell"></article>
      </section>
      <!-- V-FOR NAME AND FRAMEWORK. This loop loops all the name and frameworks and render it in a h2-->
      <section>
        <ul
          v-for="framework in frameworks"
          :key="framework.name"
          :style="{ color: framework.color }"
          className="grid grid-cols-9 text-center bg-zinc-800"
        >
          <!-- Framework on left side -->
          <li
            data-cy="chart-data-cell"
            className="m-4 text-xs mx-auto md:text-lg"
          >
            {{ framework.name }}
          </li>
          <li
            v-for="year in years"
            :key="'data_' + year"
            :style="{ color: framework.color }"
            data-cy="chart-data-cell"
            className="flex justify-center justify-around md:m-2"
          >
            <section
              v-if="framework.surveys.find((survey) => survey.year === year)"
            >
              <article
                className="border-2 rounded-full items-center justify-center flex h-8 w-8 md:h-12 md:w-12"
                data-cy="chart-circle"
                :style="{ borderColor: framework.color }"
              >
                <!-- Render retention  -->
                <p className="text-xs md:text-lg">
                  {{
                    framework.surveys.find((survey) => survey.year === year)
                      ?.retention + "%"
                  }}
                </p>
              </article>
            </section>
          </li>
          <!-- Name on the right side -->
          <li data-cy="chart-data-cell" className="m-2 text-xs md:text-lg">
            {{ framework.name }}
          </li>
        </ul>
      </section>
    </section>
  </main>
</template>
