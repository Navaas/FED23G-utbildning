<script setup lang="ts"></script>

<template>
  <footer className="flex justify-center bg-zinc-800 p-8">
    <section className="flex gap-3">
      <button
        className="bg-black text-white text-xs p-3 w-22 hover:bg-zinc-900 active:bg-zinc-900 focus:outline-none focus:ring focus:ring-slate-400 md:w-24 text-sm"
      >
        Retention
      </button>
      <button
        className="bg-black text-white text-xs p-3 w-22 hover:bg-zinc-900 focus:outline-none focus:ring focus:ring-slate-400 md:w-24 text-sm"
      >
        Interest
      </button>
      <button
        className="bg-black text-white text-xs p-3 w-22 hover:bg-zinc-900 focus:outline-none focus:ring focus:ring-slate-400 md:w-24 text-sm"
      >
        Usage
      </button>
      <button
        className="bg-black text-white text-xs p-3 w-22 hover:bg-zinc-900 focus:outline-none focus:ring focus:ring-slate-400 md:w-24 text-sm"
      >
        Awareness
      </button>
    </section>
  </footer>
</template>
