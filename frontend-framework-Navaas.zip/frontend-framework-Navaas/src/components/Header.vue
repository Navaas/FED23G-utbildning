<script setup lang="ts"></script>

<template>
  <header className="flex justify-center bg-black text-white py-8">
    <h1 className="font-bold text-sm md:text-3xl">State of Javascript</h1>
  </header>
</template>
