import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { app, mockedEntityUpdated, pathToResource } from '../src';
import { mockFileSystem } from './mock';

describe('Missing resources (404)', () => {
  let agent = request(app);
  let entitiesBefore: any[];

  beforeEach(async () => {
    mockFileSystem();
    entitiesBefore = (await agent.get(pathToResource)).body;
  });

  it('should not be able to GET a specific entity if missing (404)', async () => {
    const response = await agent.get(
      pathToResource + '/ljanbsd897ag6df5asfd6au7isuydu2'
    );
    const entitiesAfter = (await agent.get(pathToResource)).body;
    expect(response.headers['content-type']).toMatch(/json/);
    expect(response.status).toBe(404);
    expect(response.body).toBeDefined();
    expect(entitiesAfter).toStrictEqual(entitiesBefore);
  });

  it('should not be able to PUT a specific entity if missing (404)', async () => {
    const id = 'kajndba87sdg6asudb238bd78a6sgd7';
    const mockedEntity = { ...mockedEntityUpdated, id };
    const response = await agent
      .put(pathToResource + '/' + id)
      .send(mockedEntity)
      .set('Content-Type', 'application/json');
    const entitiesAfter = (await agent.get(pathToResource)).body;
    expect(response.headers['content-type']).toMatch(/json/);
    expect(response.status).toBe(404);
    expect(response.body).toBeDefined();
    expect(entitiesAfter).toStrictEqual(entitiesBefore);
  });

  it('should not be able to DELETE a specific entity if missing (404)', async () => {
    const entitiesAfter = (await agent.get(pathToResource)).body;
    const response = await agent.delete(
      pathToResource + '/a897sdg6aity2keva78s6da5surtd'
    );
    expect(response.headers['content-type']).toMatch(/json/);
    expect(response.status).toBe(404);
    expect(response.body).toBeDefined();
    expect(entitiesAfter).toStrictEqual(entitiesBefore);
  });
});
