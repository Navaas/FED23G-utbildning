import mock from 'mock-fs';
import path from 'path';

export function mockFileSystem() {
  mock({
    node_modules: mock.load(path.resolve('node_modules')),
    'db.json': '[]',
  });
}
