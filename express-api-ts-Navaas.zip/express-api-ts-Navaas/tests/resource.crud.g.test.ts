import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import {
  app,
  mockedEntityDefault,
  mockedEntityUpdated,
  pathToResource,
} from '../src';
import { mockFileSystem } from './mock';

describe('Successful responses (200, 201, 204)', () => {
  let agent = request(app);
  let newId: string | number;
  let entitiesBefore: any[];

  beforeEach(async () => {
    mockFileSystem();
    const { id, ...mockedEntityWithoutId } = mockedEntityDefault;
    const response = await agent
      .post(pathToResource)
      .send(mockedEntityWithoutId)
      .set('content-type', 'application/json');
    newId = response.body.id;
    entitiesBefore = (await agent.get(pathToResource)).body;
  });

  it('should be able to GET a list of all entities (200)', async () => {
    const response = await agent.get(pathToResource);
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/json/);
    expect(response.body.length).toBeDefined();
    expect(response.body).toStrictEqual(entitiesBefore);
  });

  it('should be able to POST a new entity (201)', async () => {
    const { id, ...mockedEntityWithoutId } = mockedEntityDefault;
    const response = await agent
      .post(pathToResource)
      .send(mockedEntityWithoutId)
      .set('content-type', 'application/json');
    const entitiesAfter = (await agent.get(pathToResource)).body;
    expect(response.status).toBe(201);
    expect(response.headers['content-type']).toMatch(/json/);
    expect(response.body).toBeTypeOf('object');
    expect(response.body.id).toBeDefined();
    expect(Object.keys(response.body).length).toBeGreaterThanOrEqual(4);
    expect(entitiesAfter).toHaveLength(entitiesBefore.length + 1);
  });

  it('should be able to GET a specific entity (200)', async () => {
    const response = await agent.get(pathToResource + '/' + newId);
    const entitiesAfter = (await agent.get(pathToResource)).body;
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/json/);
    expect(response.body.id).toBe(newId);
    expect(entitiesAfter).toStrictEqual(entitiesBefore);
  });

  it('should be able to PUT an entity (200)', async () => {
    const mockedEntity = { ...mockedEntityUpdated, id: newId };
    const response = await agent
      .put(pathToResource + '/' + newId)
      .send(mockedEntity)
      .set('Content-Type', 'application/json');
    const entitiesAfter = (await agent.get(pathToResource)).body;
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/json/);
    // Stringify both sides so dates are properly compared
    expect(JSON.stringify(response.body)).toBe(JSON.stringify(mockedEntity));
    expect(entitiesBefore).toHaveLength(entitiesAfter.length);
  });

  it('should be able to DELETE an entity (204)', async () => {
    const response = await agent.delete(pathToResource + '/' + newId);
    const entitiesAfter: any[] = (await agent.get(pathToResource)).body;
    expect(response.status).toBe(204);
    expect(entitiesAfter.find((e) => e.id === newId)).toBeUndefined();
    expect(entitiesAfter).toHaveLength(entitiesBefore.length - 1);
  });
});
