import fs from 'fs/promises';
import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import {
  app,
  mockedEntityDefault,
  mockedEntityUpdated,
  pathToResource,
} from '../src';
import { mockFileSystem } from './mock';

describe('Persisting the data', () => {
  let agent = request(app);
  let newId: string | number;

  beforeEach(async () => {
    mockFileSystem();
    const { id, ...mockedEntityWithoutId } = mockedEntityDefault;
    const response = await agent
      .post(pathToResource)
      .send(mockedEntityWithoutId)
      .set('content-type', 'application/json');
    newId = response.body.id;
  });

  it('should persist an entity that was added (POST)', async () => {
    const { id, ...mockedEntityWithoutId } = mockedEntityDefault;
    const response = await agent
      .post(pathToResource)
      .send(mockedEntityWithoutId);
    const newId = response.body.id;

    const storedEntities = await readStoredEntities();
    const storedEntity = storedEntities.find((e) => e.id === newId);
    expect(response.status).toBe(201);
    expect(storedEntity).toStrictEqual(response.body);
    expect(storedEntities.length).toBe(2);
  });

  it('should persist an entity that was updated (PUT)', async () => {
    const mockedEntity = { ...mockedEntityUpdated, id: newId };
    const response = await agent
      .put(pathToResource + '/' + newId)
      .send(mockedEntity);

    const storedEntities = await readStoredEntities();
    const storedEntity = storedEntities.find((e) => e.id === newId);
    expect(response.status).toBe(200);
    expect(storedEntity).toStrictEqual(response.body);
    expect(storedEntities.length).toBe(1);
  });

  it('should persist an entity that was deleted (DELETE)', async () => {
    const response = await agent.delete(pathToResource + '/' + newId);
    const storedEntities = await readStoredEntities();
    const storedEntity = storedEntities.find((e) => e.id === newId);
    expect(response.status).toBe(204);
    expect(storedEntity).toBeUndefined();
    expect(storedEntities.length).toBe(0);
  });
});

async function readStoredEntities(): Promise<any[]> {
  const storedEntityListString = await fs.readFile('db.json', {
    encoding: 'utf8',
  });
  return JSON.parse(storedEntityListString);
}
