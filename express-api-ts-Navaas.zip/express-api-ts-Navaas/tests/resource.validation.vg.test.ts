import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import {
  app,
  mockedEntityDefault,
  mockedEntityUpdated,
  pathToResource,
} from '../src';
import { mockFileSystem } from './mock';

describe('Validating incoming data (400)', () => {
  let agent = request(app);
  let newId: string | number;
  let entitiesBefore: any[];

  beforeEach(async () => {
    mockFileSystem();
    const { id, ...mockedEntityWithoutId } = mockedEntityDefault;
    const response = await agent
      .post(pathToResource)
      .send(mockedEntityWithoutId)
      .set('content-type', 'application/json');
    newId = response.body.id;
    entitiesBefore = (await agent.get(pathToResource)).body;
  });

  it('should not be possible to POST an entity that have missing properties (400)', async () => {
    let response = await agent.post(pathToResource).send({});
    let entitiesAfter = (await agent.get(pathToResource)).body;
    expect(response.status).toBe(400);
    expect(response.body).toBeDefined();
    expect(entitiesAfter).toStrictEqual(entitiesBefore);
  });

  it('should not be possible to POST an entity that have additional properties (400)', async () => {
    const mockedEntityWithAdditionalProperties = {
      ...mockedEntityDefault,
      fieldThatShouldNotBeAccepted: 'error',
    };
    const response = await agent
      .post(pathToResource)
      .send(mockedEntityWithAdditionalProperties);
    const entitiesAfter = (await agent.get(pathToResource)).body;
    expect(response.status).toBe(400);
    expect(response.body).toBeDefined();
    expect(entitiesAfter).toStrictEqual(entitiesBefore);
  });

  it('should not be possible to PUT an entity that have missing properties (400)', async () => {
    const response = await agent.put(pathToResource + '/' + newId).send({});
    const entitiesAfter = (await agent.get(pathToResource)).body;
    expect(response.status).toBe(400);
    expect(response.body).toBeDefined();
    expect(entitiesAfter).toStrictEqual(entitiesBefore);
  });

  it('should not be possible to PUT an entity that have additional properties (400)', async () => {
    const mockedEntityWithAdditionalProperties = {
      ...mockedEntityDefault,
      fieldThatShouldNotBeAccepted: 'error',
    };
    const response = await agent
      .put(pathToResource + '/' + newId)
      .send(mockedEntityWithAdditionalProperties);
    const entitiesAfter = (await agent.get(pathToResource)).body;
    expect(response.status).toBe(400);
    expect(response.body).toBeDefined();
    expect(entitiesAfter).toStrictEqual(entitiesBefore);
  });
  it('should not be possible to PUT if the id has been changed (400)', async () => {
    const response = await agent
      .put(pathToResource + '/' + newId)
      .send({ ...mockedEntityUpdated, id: 'au98sdga76ysdbuas7d6tur2' });
    const entitiesAfter = (await agent.get(pathToResource)).body;
    expect(response.status).toBe(400);
    expect(response.body).toBeDefined();
    expect(entitiesAfter).toStrictEqual(entitiesBefore);
  });
});
