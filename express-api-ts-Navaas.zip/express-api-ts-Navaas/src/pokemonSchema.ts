import { z } from "zod";

export const PokemonSchema = z
  .object({
    id: z.string(),
    name: z.string(),
    type: z.string(),
    level: z.number(),
  })
  .strict();

export const PokemonCreateSchema = PokemonSchema.omit({
  id: true,
});

export type PokemonType = z.infer<typeof PokemonSchema>;
export type PokemonCreateType = z.infer<typeof PokemonCreateSchema>;
