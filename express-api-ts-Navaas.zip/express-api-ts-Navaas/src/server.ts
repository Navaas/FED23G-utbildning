import { app } from './app';

app.listen(3000, () => console.log('Running on: http://localhost:3000'));

// Den här filen behöver inte ändras.
