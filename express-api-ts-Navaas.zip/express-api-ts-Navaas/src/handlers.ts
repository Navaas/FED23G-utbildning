import { NextFunction, Request, Response } from "express";
import { readDB, writeDB } from "./databas";
import { PokemonCreateSchema, PokemonSchema } from "./pokemonSchema";

export const startPage = (req: Request, res: Response, next: NextFunction) => {
  res.json("Välkommen till en värld av Pokemon");
  res.status(200);
};

export const getAllPokemon = async (req: Request, res: Response) => {
  const pokemonList = await readDB();
  res.status(200).json(pokemonList);
};

export const createNewPokemon = async (req: Request, res: Response) => {
  const pokemonList = await readDB();
  try {
    const newPokemonData = PokemonCreateSchema.parse(req.body);
    const newPokemon = {
      id: Date.now().toString(),
      ...newPokemonData,
    };

    pokemonList.push(newPokemon);
    await writeDB(pokemonList);
    res.status(201).json(newPokemon);
  } catch (error) {
    res.status(400).json("Kunde inte skapa en ny pokemon");
  }
};

export const updateExistPokemon = async (req: Request, res: Response) => {
  const { id } = req.params;
  const pokemonList = await readDB();
  const existingPokemonIndex = pokemonList.findIndex(
    (pokemon) => pokemon.id === id
  );

  try {
    const updatedPokemonData = PokemonSchema.parse(req.body);

    if (id !== updatedPokemonData.id) {
      res.status(400).json("Kan inte uppdatera ett befintligt id");
      return;
    }

    if (existingPokemonIndex === -1) {
      res.status(404).json("Pokemon kunde inte hittas");
      return;
    }

    pokemonList[existingPokemonIndex] = updatedPokemonData;
    await writeDB(pokemonList);
    res.status(200).json(pokemonList[existingPokemonIndex]);
  } catch (error) {
    return res.status(400).json("Någonting med din begäran gick fel");
  }
};

export const getExistPokemonById = async (req: Request, res: Response) => {
  const { id } = req.params;
  const pokemonList = await readDB();
  const pokemon = pokemonList.find((pokemon) => pokemon.id === id);
  if (pokemon) {
    res.status(200).json(pokemon);
  } else {
    res.status(404).json("Pokemon kunde inte hittas");
  }
};

export const deleteExistPokemon = async (req: Request, res: Response) => {
  const { id } = req.params;
  const pokemonList = await readDB();
  const index = pokemonList.findIndex((pokemon) => pokemon.id === id);

  if (index !== -1) {
    pokemonList.splice(index, 1);
    await writeDB(pokemonList);
    res.status(204).json("Din pokemon är borttagen");
  } else {
    res.status(404).json("Kunde inte hitta denna pokemon");
  }
};

export const urlNotExist = (req: Request, res: Response) => {
  res.status(404).json("Denna url finns inte");
};
