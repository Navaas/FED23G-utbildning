/*
 * Hej student! I den här filen beskriver du för testerna hur ditt API ser ut.
 * Tänk på att inte ändra variabelnamnen nedan utan bara det som tilldelas.
 */

import { Pokemon } from "./app";

// Sökvägen till resursen i ditt API:
export const pathToResource = "/pokemon";

// Beskriv hur en entitet kan se ut:
export const mockedEntityDefault: Pokemon = {
  id: "1",
  name: "Pikachu",
  type: "Electric",
  level: 4,
};
// Ge ett annat exempel på hur en entitet kan se ut:
export const mockedEntityUpdated: Pokemon = {
  id: "2",
  name: "Bulbarsaur",
  type: "Trees",
  level: 99,

  // string: 'updated entity',
  // number: 149,
  // date: new Date('2022-12-31'),
  // list: [4, 4, 4],
};
