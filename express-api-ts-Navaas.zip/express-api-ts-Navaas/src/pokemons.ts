export const pokemons = [
  {
    id: "1",
    name: "Pikachu",
    type: "Electric",
    level: 25,
  },
  {
    id: "2",
    name: "Bulbasaur",
    type: "Grass/Poison",
    level: 36,
  },
  {
    id: "3",
    name: "Squirtle",
    type: "Water",
    level: 18,
  },
  {
    id: "4",
    name: "Jigglypuff",
    type: "Normal/Fairy",
    level: 20,
  },
  {
    id: "5",
    name: "Togepi",
    type: "Fairy",
    level: 5,
  },
];
