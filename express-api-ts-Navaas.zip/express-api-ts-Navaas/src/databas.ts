import { error } from "console";
import fs from "fs/promises";
import { Pokemon } from "./app";

const databas = "db.json";

export async function readDB(): Promise<Pokemon[]> {
  try {
    const data = await fs.readFile(databas, "utf8");
    return JSON.parse(data);
  } catch (error) {
    console.log(error);
    return [];
  }
}

export async function writeDB(data: Pokemon[]) {
  try {
    await fs.writeFile(databas, JSON.stringify(data, null, 4), "utf8");
  } catch {
    console.error(error);
  }
}

export async function updateDatabas() {
  const data = await readDB();
  await writeDB(data);
}
