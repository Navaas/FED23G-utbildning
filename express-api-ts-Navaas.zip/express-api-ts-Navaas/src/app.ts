import express, { NextFunction, Request, Response } from "express";
import {
  createNewPokemon,
  deleteExistPokemon,
  getAllPokemon,
  getExistPokemonById,
  startPage,
  updateExistPokemon,
  urlNotExist,
} from "./handlers";

export interface Pokemon {
  id: string | number;
  name: string;
  type: string;
  level: number;
}

function logger(req: Request, res: Response, next: NextFunction): void {
  console.log(new Date().toISOString(), req.method, req.url);
  next();
}

export const app = express();

app.use(express.json());
app.use(logger);

app.get("/", startPage);
app.get("/pokemon", getAllPokemon);
app.post("/pokemon", createNewPokemon);
app.put("/pokemon/:id", updateExistPokemon);
app.get("/pokemon/:id", getExistPokemonById);
app.delete("/pokemon/:id", deleteExistPokemon);
app.use("*", urlNotExist);
