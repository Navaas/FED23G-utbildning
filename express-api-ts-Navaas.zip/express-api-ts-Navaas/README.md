# Basic REST-API

Här skapas ett basic rest-api med NodeJS med Express och typescript. Full funktionallitet för CRUD där endpoints innehållet, GET, POST, PUT, DELETE. Api:t innehåller Pokemons.

### Start

- npm install
- npm run dev

### Test

VS code, REST Client. (Extensions)

**Krav för godkänt:**

- [x] Projektet innehåller CRUD endpoints (GET, POST, PUT & DELETE) för en resurs
- [x] Datan som API:et hanterar sparas lokalt i serverfilen
- [x] APIét ska svara med 404 om datan saknas.
- [x] Git & GitHub har använts
- [x] Projektmappen innehåller en README.md
- **Krav för väl godkänt:**

- [x] Alla punkter för godkänt är uppfyllda
- [x] Dina enpoints ska ha validering
- [x] Datan som API:et hanterar sparas till disk
